import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
import re
import os
import sys
import datetime
import time
import shutil
from PIL import Image, ImageTk

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

class DocumentManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Document Management System")
        self.root.geometry("900x600")
        self.root.configure(bg="#f0f0f0")
        
        # Center the window
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        x = (screen_width/2) - (900/2)
        y = (screen_height/2) - (600/2)
        self.root.geometry(f'900x600+{int(x)}+{int(y)}')

        # Initialize database
        self.create_database()
        
        # Create main frame
        self.main_frame = tk.Frame(root, bg="#f0f0f0")
        self.main_frame.pack(expand=True, fill="both", padx=20, pady=20)
        
        # Create and show login frame
        self.show_login()
    
    def create_database(self):
        db_path = 'document_management.db'
        if hasattr(sys, '_MEIPASS'):
            # If running as exe, store db in same directory as exe
            db_path = os.path.join(os.path.dirname(sys.executable), 'document_management.db')
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        try:
            # Create users table with is_admin field
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    is_admin BOOLEAN DEFAULT 0
                )
            ''')
            
            # Check if admin account exists, if not create it
            cursor.execute("SELECT * FROM users WHERE email = ?", ('fiafghan@admin.com',))
            if not cursor.fetchone():
                cursor.execute("""
                    INSERT INTO users (username, password, email, is_admin)
                    VALUES (?, ?, ?, ?)
                """, ('admin', 'admin123', 'fiafghan@admin.com', 1))
                conn.commit()
            
            # Update existing admin account if it exists
            cursor.execute("UPDATE users SET is_admin = 1 WHERE email = ?", ('fiafghan@admin.com',))
            conn.commit()
            
            # Create student_documents table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS student_documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_name TEXT NOT NULL,
                    student_name TEXT NOT NULL,
                    student_id TEXT NOT NULL,
                    father_name TEXT NOT NULL,
                    last_name TEXT NOT NULL,
                    document_type TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    file_type TEXT NOT NULL,
                    uploader TEXT NOT NULL,
                    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (uploader) REFERENCES users (username)
                )
            ''')
            
            # Create messages table for direct messages
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sender TEXT NOT NULL,
                    receiver TEXT NOT NULL,
                    message_text TEXT NOT NULL,
                    is_public BOOLEAN NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (sender) REFERENCES users (username),
                    FOREIGN KEY (receiver) REFERENCES users (username)
                )
            ''')
            
            # Create message_attachments table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS message_attachments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id INTEGER NOT NULL,
                    file_name TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    file_type TEXT NOT NULL,
                    FOREIGN KEY (message_id) REFERENCES messages (id)
                )
            ''')
            
            # Create exam_results table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS exam_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    class_code TEXT NOT NULL,
                    department TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    teacher TEXT NOT NULL,
                    semester INTEGER NOT NULL,
                    semester_type TEXT NOT NULL,
                    start_time TEXT NOT NULL,
                    end_time TEXT NOT NULL,
                    year INTEGER NOT NULL,
                    created_by TEXT NOT NULL,
                    document_path TEXT,
                    document_name TEXT,
                    document_type TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (created_by) REFERENCES users (username)
                )
            ''')
            
            # Create results table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    class_code TEXT NOT NULL,
                    faculty TEXT NOT NULL,
                    department TEXT NOT NULL,
                    year INTEGER NOT NULL,
                    semester INTEGER NOT NULL CHECK (semester >= 1 AND semester <= 8),
                    semester_type TEXT NOT NULL CHECK (semester_type IN ('fall', 'spring')),
                    file_path TEXT NOT NULL,
                    file_type TEXT NOT NULL,
                    uploader TEXT NOT NULL,
                    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (uploader) REFERENCES users (username)
                )
            ''')
            
            # Create attendance table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS attendance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    class_code TEXT NOT NULL,
                    faculty TEXT NOT NULL,
                    department TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    teacher TEXT NOT NULL,
                    year INTEGER NOT NULL,
                    semester INTEGER NOT NULL CHECK (semester >= 1 AND semester <= 8),
                    semester_type TEXT NOT NULL CHECK (semester_type IN ('fall', 'spring')),
                    file_path TEXT NOT NULL,
                    file_type TEXT NOT NULL,
                    uploader TEXT NOT NULL,
                    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (uploader) REFERENCES users (username)
                )
            ''')

            conn.commit()
        except Exception as e:
            print(f"Database error: {str(e)}")
            conn.rollback()
        finally:
            conn.close()
    
    def show_login(self):
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        # Create login frame
        login_frame = tk.Frame(self.main_frame, bg="white", highlightthickness=1)
        login_frame.place(relx=0.5, rely=0.5, anchor="center", width=400, height=600)
        
        # Load and display logo
        try:
            logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logo.jpg')
            logo_image = Image.open(logo_path)
            # Resize image to fit the frame (adjust size as needed)
            logo_image = logo_image.resize((100, 100), Image.Resampling.LANCZOS)
            logo_photo = ImageTk.PhotoImage(logo_image)
            
            logo_label = tk.Label(login_frame, image=logo_photo, bg="white")
            logo_label.image = logo_photo  # Keep a reference!
            logo_label.pack(pady=(20, 10))
        except Exception as e:
            print(f"Error loading logo: {e}")
        
        # System name
        system_name = tk.Label(login_frame, text="Tolo Aftab Documents Management System", 
                             font=("Helvetica", 12, "bold"), bg="white", fg="#333333", wraplength=350)
        system_name.pack(pady=(0, 5))
        
        # Developer info
        developer_info = tk.Label(login_frame, text="Developed By Fardin Ibrahimi In Nov 2024", 
                                font=("Helvetica", 8), bg="white", fg="#666666")
        developer_info.pack(pady=(0, 20))
        
        # Title
        title_label = tk.Label(login_frame, text="LOGIN", font=("Helvetica", 18, "bold"), bg="white", fg="#333333")
        title_label.pack(pady=(0, 30))
        
        # Username
        username_frame = tk.Frame(login_frame, bg="white")
        username_frame.pack(fill="x", padx=50, pady=10)
        
        username_label = tk.Label(username_frame, text="Username", font=("Helvetica", 10), bg="white", fg="#666666")
        username_label.pack(anchor="w")
        
        self.username_entry = ttk.Entry(username_frame, font=("Helvetica", 12))
        self.username_entry.pack(fill="x", pady=(5, 0))
        
        # Password
        password_frame = tk.Frame(login_frame, bg="white")
        password_frame.pack(fill="x", padx=50, pady=10)
        
        password_label = tk.Label(password_frame, text="Password", font=("Helvetica", 10), bg="white", fg="#666666")
        password_label.pack(anchor="w")
        
        self.password_entry = ttk.Entry(password_frame, show="●", font=("Helvetica", 12))
        self.password_entry.pack(fill="x", pady=(5, 0))
        
        # Login button
        style = ttk.Style()
        style.configure("Custom.TButton", padding=10)
        
        login_button = ttk.Button(login_frame, text="Login", style="Custom.TButton", command=self.login)
        login_button.pack(pady=30)
        
        # Sign up link
        signup_link_frame = tk.Frame(login_frame, bg="white")
        signup_link_frame.pack(pady=(0, 20))
        
        dont_have_account = tk.Label(signup_link_frame, text="Don't have an account? ", bg="white", fg="#666666")
        dont_have_account.pack(side="left")
        
        signup_link = tk.Label(signup_link_frame, text="Sign Up", bg="white", fg="#007bff", cursor="hand2")
        signup_link.pack(side="left")
        signup_link.bind("<Button-1>", lambda e: self.show_signup())
    
    def show_signup(self):
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        # Create signup frame
        signup_frame = tk.Frame(self.main_frame, bg="white", highlightthickness=1)
        signup_frame.place(relx=0.5, rely=0.5, anchor="center", width=400, height=700)
        
        # Load and display logo
        try:
            logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logo.jpg')
            logo_image = Image.open(logo_path)
            # Resize image to fit the frame (adjust size as needed)
            logo_image = logo_image.resize((100, 100), Image.Resampling.LANCZOS)
            logo_photo = ImageTk.PhotoImage(logo_image)
            
            logo_label = tk.Label(signup_frame, image=logo_photo, bg="white")
            logo_label.image = logo_photo  # Keep a reference!
            logo_label.pack(pady=(20, 10))
        except Exception as e:
            print(f"Error loading logo: {e}")
            
        # System name
        system_name = tk.Label(signup_frame, text="Tolo Aftab Documents Management System", 
                             font=("Helvetica", 12, "bold"), bg="white", fg="#333333", wraplength=350)
        system_name.pack(pady=(0, 5))
        
        # Developer info
        developer_info = tk.Label(signup_frame, text="Developed By Fardin Ibrahimi In Nov 2024", 
                                font=("Helvetica", 8), bg="white", fg="#666666")
        developer_info.pack(pady=(0, 20))
        
        # Title
        title_label = tk.Label(signup_frame, text="SIGN UP", font=("Helvetica", 18, "bold"), bg="white", fg="#333333")
        title_label.pack(pady=(0, 30))
        
        # Username
        username_frame = tk.LabelFrame(signup_frame, text="Username", bg="white", padx=10, pady=10)
        username_frame.pack(fill="x", padx=20, pady=(0,20))
        
        self.new_username_entry = ttk.Entry(username_frame, font=("Helvetica", 12))
        self.new_username_entry.pack(fill="x", pady=(5, 0))
        
        # Email
        email_frame = tk.Frame(signup_frame, bg="white")
        email_frame.pack(fill="x", padx=50, pady=10)
        
        email_label = tk.Label(email_frame, text="Email", font=("Helvetica", 10), bg="white", fg="#666666")
        email_label.pack(anchor="w")
        
        self.email_entry = ttk.Entry(email_frame, font=("Helvetica", 12))
        self.email_entry.pack(fill="x", pady=(5, 0))
        
        # Password
        password_frame = tk.Frame(signup_frame, bg="white")
        password_frame.pack(fill="x", padx=50, pady=10)
        
        password_label = tk.Label(password_frame, text="Password", font=("Helvetica", 10), bg="white", fg="#666666")
        password_label.pack(anchor="w")
        
        self.new_password_entry = ttk.Entry(password_frame, show="●", font=("Helvetica", 12))
        self.new_password_entry.pack(fill="x", pady=(5, 0))
        
        # Confirm Password
        conf_password_frame = tk.Frame(signup_frame, bg="white")
        conf_password_frame.pack(fill="x", padx=50, pady=10)
        
        conf_password_label = tk.Label(conf_password_frame, text="Confirm Password", font=("Helvetica", 10), bg="white", fg="#666666")
        conf_password_label.pack(anchor="w")
        
        self.conf_password_entry = ttk.Entry(conf_password_frame, show="●", font=("Helvetica", 12))
        self.conf_password_entry.pack(fill="x", pady=(5, 0))
        
        # Sign up button
        signup_button = ttk.Button(signup_frame, text="Sign Up", style="Custom.TButton", command=self.signup)
        signup_button.pack(pady=30)
        
        # Login link
        login_link_frame = tk.Frame(signup_frame, bg="white")
        login_link_frame.pack(pady=(0, 20))
        
        have_account = tk.Label(login_link_frame, text="Already have an account? ", bg="white", fg="#666666")
        have_account.pack(side="left")
        
        login_link = tk.Label(login_link_frame, text="Login", bg="white", fg="#007bff", cursor="hand2")
        login_link.pack(side="left")
        login_link.bind("<Button-1>", lambda e: self.show_login())
    
    def validate_email(self, email):
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please fill in all fields")
            return
        
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        
        # First, let's check if we need to add the is_admin column
        cursor.execute("PRAGMA table_info(users)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'is_admin' not in columns:
            # Add is_admin column if it doesn't exist
            cursor.execute("ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT 0")
            # Set admin privileges for fiafghan@admin.com
            cursor.execute("UPDATE users SET is_admin = 1 WHERE email = ?", ('fiafghan@admin.com',))
            conn.commit()
        
        cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = cursor.fetchone()
        
        conn.close()
        
        if user:
            self.current_user = {
                'id': user[0],
                'username': user[1],
                'email': user[3],
                'is_admin': bool(user[4]) if len(user) > 4 else (user[3] == 'fiafghan@admin.com')
            }
            self.show_dashboard()
        else:
            messagebox.showerror("Error", "Invalid username or password")
    
    def show_dashboard(self):
        # Clear the root window
        for widget in self.root.winfo_children():
            widget.destroy()
            
        # Create new main frame
        self.main_frame = tk.Frame(self.root, bg="#f0f0f0")
        self.main_frame.pack(expand=True, fill="both", padx=20, pady=20)
            
        # Create main dashboard container
        dashboard = tk.Frame(self.main_frame, bg="#f0f0f0")
        dashboard.pack(fill="both", expand=True)
        
        # Top bar with user info and logout
        top_bar = tk.Frame(dashboard, bg="white", height=60)
        top_bar.pack(fill="x", padx=10, pady=(0, 10))
        top_bar.pack_propagate(False)
        
        welcome_label = tk.Label(top_bar, text=f"Welcome, {self.current_user['username']}", 
                               font=("Helvetica", 12, "bold"), bg="white")
        welcome_label.pack(side="left", padx=20)
        
        logout_btn = ttk.Button(top_bar, text="Logout", command=self.show_login)
        logout_btn.pack(side="right", padx=20, pady=10)
        
        # Main content area
        content_frame = tk.Frame(dashboard, bg="#f0f0f0")
        content_frame.pack(fill="both", expand=True, padx=10)
        
        # Left sidebar with actions
        sidebar = tk.Frame(content_frame, bg="white", width=200)
        sidebar.pack(side="left", fill="y", padx=(0, 10))
        sidebar.pack_propagate(False)
        
        # Sidebar buttons
        ttk.Button(sidebar, text="Profile", command=self.view_profile).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="Security", command=self.view_security).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="Messages", command=self.view_messages).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="Upload Document", command=self.view_upload_document).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="View All Documents", command=self.view_all_documents).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="Exam Results", command=self.view_exam_results).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="Results Table", command=self.show_results_page).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="Attendance Upload", command=self.view_attendance_upload).pack(fill="x", padx=10, pady=5)
        ttk.Button(sidebar, text="View Attendance", command=self.view_attendance).pack(fill="x", padx=10, pady=5)
        
        # Add Account Control button for fiafghan@gmail.com
        if self.current_user['email'].lower().strip() == 'fiafghan@gmail.com':
            ttk.Button(sidebar, text="Account Control", command=self.show_account_control).pack(fill="x", padx=10, pady=5)
            ttk.Button(sidebar, text="Statistics", command=self.view_statistics).pack(fill="x", padx=10, pady=5)
        
        # Main content area (right side)
        self.content_area = tk.Frame(content_frame, bg="white")
        self.content_area.pack(side="left", fill="both", expand=True)
        
        # Show profile by default
        self.view_profile()
    
    def view_profile(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        # Create profile view
        profile_frame = tk.Frame(self.content_area, bg="white")
        profile_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(profile_frame, text="Profile Information", 
                font=("Helvetica", 18, "bold"), bg="white").pack(pady=(0,20))
        
        # Display user information
        info_frame = tk.Frame(profile_frame, bg="white")
        info_frame.pack(fill="x", padx=20)
        
        tk.Label(info_frame, text="Username:", font=("Helvetica", 12, "bold"), 
                bg="white").grid(row=0, column=0, sticky="e", padx=10, pady=5)
        tk.Label(info_frame, text=self.current_user['username'], 
                bg="white").grid(row=0, column=1, sticky="w", pady=5)
        
        tk.Label(info_frame, text="Email:", font=("Helvetica", 12, "bold"), 
                bg="white").grid(row=1, column=0, sticky="e", padx=10, pady=5)
        tk.Label(info_frame, text=self.current_user['email'], 
                bg="white").grid(row=1, column=1, sticky="w", pady=5)
    
    def view_security(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        # Create security view
        security_frame = tk.Frame(self.content_area, bg="white")
        security_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(security_frame, text="Security Settings", 
                font=("Helvetica", 18, "bold"), bg="white").pack(pady=(0,20))
        
        # Change Username Section
        username_frame = tk.LabelFrame(security_frame, text="Change Username", bg="white", padx=10, pady=10)
        username_frame.pack(fill="x", padx=20, pady=(0,20))
        
        tk.Label(username_frame, text="Current Username:", bg="white").pack(anchor="w")
        tk.Label(username_frame, text=self.current_user['username'], 
                bg="white", font=("Helvetica", 10, "bold")).pack(anchor="w", pady=(0,10))
        
        tk.Label(username_frame, text="New Username:", bg="white").pack(anchor="w")
        new_username_entry = ttk.Entry(username_frame, width=30)
        new_username_entry.pack(anchor="w", pady=(0,10))
        
        def update_username():
            new_username = new_username_entry.get().strip()
            if not new_username:
                messagebox.showerror("Error", "Please enter a new username")
                return
                
            if new_username == self.current_user['username']:
                messagebox.showerror("Error", "New username must be different from current username")
                return
                
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            try:
                cursor.execute("UPDATE users SET username = ? WHERE id = ?", 
                             (new_username, self.current_user['id']))
                conn.commit()
                self.current_user['username'] = new_username
                messagebox.showinfo("Success", "Username updated successfully!")
                self.show_dashboard()  # Refresh dashboard to show new username
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Username already exists")
            finally:
                conn.close()
        
        ttk.Button(username_frame, text="Update Username", command=update_username).pack(anchor="w")
        
        # Change Password Section
        password_frame = tk.LabelFrame(security_frame, text="Change Password", bg="white", padx=10, pady=10)
        password_frame.pack(fill="x", padx=20, pady=(0,20))
        
        tk.Label(password_frame, text="Current Password:", bg="white").pack(anchor="w")
        current_password_entry = ttk.Entry(password_frame, show="●", width=30)
        current_password_entry.pack(anchor="w", pady=(0,10))
        
        tk.Label(password_frame, text="New Password:", bg="white").pack(anchor="w")
        new_password_entry = ttk.Entry(password_frame, show="●", width=30)
        new_password_entry.pack(anchor="w", pady=(0,10))
        
        tk.Label(password_frame, text="Confirm New Password:", bg="white").pack(anchor="w")
        confirm_password_entry = ttk.Entry(password_frame, show="●", width=30)
        confirm_password_entry.pack(anchor="w", pady=(0,10))
        
        def update_password():
            current_password = current_password_entry.get()
            new_password = new_password_entry.get()
            confirm_password = confirm_password_entry.get()
            
            if not all([current_password, new_password, confirm_password]):
                messagebox.showerror("Error", "Please fill in all password fields")
                return
                
            if new_password != confirm_password:
                messagebox.showerror("Error", "New passwords do not match")
                return
                
            if current_password == new_password:
                messagebox.showerror("Error", "New password must be different from current password")
                return
                
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            # Verify current password
            cursor.execute("SELECT * FROM users WHERE id = ? AND password = ?", 
                         (self.current_user['id'], current_password))
            if not cursor.fetchone():
                messagebox.showerror("Error", "Current password is incorrect")
                conn.close()
                return
            
            # Update password
            cursor.execute("UPDATE users SET password = ? WHERE id = ?", 
                         (new_password, self.current_user['id']))
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Success", "Password updated successfully!")
            current_password_entry.delete(0, tk.END)
            new_password_entry.delete(0, tk.END)
            confirm_password_entry.delete(0, tk.END)
        
        ttk.Button(password_frame, text="Update Password", command=update_password).pack(anchor="w")
    
    def view_upload_document(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        # Create upload document view
        upload_frame = tk.Frame(self.content_area, bg="white")
        upload_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(upload_frame, text="Upload Document", 
                font=("Helvetica", 18, "bold"), bg="white").pack(pady=(0,20))
        
        # Create form
        form_frame = tk.Frame(upload_frame, bg="white")
        form_frame.pack(fill="x", padx=20)
        
        # Document name
        tk.Label(form_frame, text="Document Name:", bg="white").grid(row=0, column=0, sticky="e", padx=10, pady=5)
        doc_name_entry = ttk.Entry(form_frame, width=40)
        doc_name_entry.grid(row=0, column=1, sticky="w", pady=(5, 0))
        
        # Student name
        tk.Label(form_frame, text="Student Name:", bg="white").grid(row=1, column=0, sticky="e", padx=10, pady=5)
        student_name_entry = ttk.Entry(form_frame, width=40)
        student_name_entry.grid(row=1, column=1, sticky="w", pady=(5, 0))
        
        # Student ID
        tk.Label(form_frame, text="Student ID:", bg="white").grid(row=2, column=0, sticky="e", padx=10, pady=5)
        student_id_entry = ttk.Entry(form_frame, width=40)
        student_id_entry.grid(row=2, column=1, sticky="w", pady=(5, 0))
        
        # Father's name
        tk.Label(form_frame, text="Father's Name:", bg="white").grid(row=3, column=0, sticky="e", padx=10, pady=5)
        father_name_entry = ttk.Entry(form_frame, width=40)
        father_name_entry.grid(row=3, column=1, sticky="w", pady=(5, 0))
        
        # Last name
        tk.Label(form_frame, text="Last Name:", bg="white").grid(row=4, column=0, sticky="e", padx=10, pady=5)
        last_name_entry = ttk.Entry(form_frame, width=40)
        last_name_entry.grid(row=4, column=1, sticky="w", pady=(5, 0))
        
        # Document type dropdown
        tk.Label(form_frame, text="Document Type:", bg="white").grid(row=5, column=0, sticky="e", padx=10, pady=5)
        doc_types = [
            "National ID card",
            "School certificate",
            "Photo",
            "Transfer documents",
            "Deferment documents",
            "Diploma",
            "Transcript",
            "Passport",
            "CV",
            "Diploma and transcript application document",
            "Monograph Defense Paper"
        ]
        doc_type_var = tk.StringVar()
        doc_type_dropdown = ttk.Combobox(form_frame, textvariable=doc_type_var, values=doc_types, 
                                       width=37, state="readonly")
        doc_type_dropdown.grid(row=5, column=1, sticky="w", pady=(5, 0))
        
        # Uploader (automatically filled)
        tk.Label(form_frame, text="Uploader:", bg="white").grid(row=6, column=0, sticky="e", padx=10, pady=5)
        tk.Label(form_frame, text=self.current_user['username'], bg="white").grid(row=6, column=1, sticky="w", pady=(5, 0))
        
        # Upload date (automatically filled)
        tk.Label(form_frame, text="Upload Date:", bg="white").grid(row=7, column=0, sticky="e", padx=10, pady=5)
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        tk.Label(form_frame, text=current_time, bg="white").grid(row=7, column=1, sticky="w", pady=(5, 0))
        
        # File selection
        tk.Label(form_frame, text="Select File:", bg="white").grid(row=8, column=0, sticky="e", padx=10, pady=5)
        file_path_var = tk.StringVar()
        file_path_label = tk.Label(form_frame, textvariable=file_path_var, bg="white", width=40, anchor="w")
        file_path_label.grid(row=8, column=1, sticky="w", pady=(5, 0))
        
        def browse_file():
            filetypes = (
                ('PDF files', '*.pdf'),
                ('Word files', '*.doc;*.docx'),
                ('Excel files', '*.xls;*.xlsx'),
                ('Image files', '*.png;*.jpg;*.jpeg')
            )
            filename = filedialog.askopenfilename(
                title='Select a document',
                filetypes=filetypes
            )
            if filename:
                file_path_var.set(filename)
        
        ttk.Button(form_frame, text="Browse", command=browse_file).grid(row=8, column=2, padx=5, pady=(5, 0))
        
        def upload_document():
            # Validate all fields
            if not all([
                doc_name_entry.get().strip(),
                student_name_entry.get().strip(),
                student_id_entry.get().strip(),
                father_name_entry.get().strip(),
                last_name_entry.get().strip(),
                doc_type_var.get(),
                file_path_var.get()
            ]):
                messagebox.showerror("Error", "Please fill in all fields")
                return
            
            # Validate file type
            file_path = file_path_var.get()
            file_ext = os.path.splitext(file_path)[1].lower()
            
            allowed_extensions = {'.pdf', '.doc', '.docx', '.xls', '.xlsx', '.png', '.jpg', '.jpeg'}
            
            if file_ext not in allowed_extensions:
                messagebox.showerror("Error", "Invalid file type. Only PDF, Word, Excel, and image files are allowed.")
                return
            
            # Create documents directory if it doesn't exist
            docs_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'documents')
            os.makedirs(docs_dir, exist_ok=True)
            
            # Copy file to documents directory with unique name
            new_filename = f"{int(time.time())}_{os.path.basename(file_path)}"
            new_file_path = os.path.join(docs_dir, new_filename)
            shutil.copy2(file_path, new_file_path)
            
            # Save to database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO student_documents (
                    document_name, student_name, student_id, father_name, last_name,
                    document_type, file_path, file_type, uploader, upload_date
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                doc_name_entry.get().strip(),
                student_name_entry.get().strip(),
                student_id_entry.get().strip(),
                father_name_entry.get().strip(),
                last_name_entry.get().strip(),
                doc_type_var.get(),
                new_file_path,
                file_ext,
                self.current_user['username'],
                current_time
            ))
            
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Success", "Document uploaded successfully!")
            
            # Clear form
            for entry in [doc_name_entry, student_name_entry, student_id_entry, 
                         father_name_entry, last_name_entry]:
                entry.delete(0, tk.END)
            doc_type_dropdown.set('')
            file_path_var.set('')
        
        # Upload button
        ttk.Button(form_frame, text="Upload Document", command=upload_document).grid(row=9, column=1, pady=20)
    
    def view_all_documents(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        # Create documents view
        docs_frame = tk.Frame(self.content_area, bg="white")
        docs_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title and search frame
        title_frame = tk.Frame(docs_frame, bg="white")
        title_frame.pack(fill="x", pady=(0,20))
        
        tk.Label(title_frame, text="All Documents", 
                font=("Helvetica", 18, "bold"), bg="white").pack(side="left")
        
        # Search frame
        search_frame = tk.Frame(title_frame, bg="white")
        search_frame.pack(side="right")
        
        tk.Label(search_frame, text="Search:", bg="white").pack(side="left", padx=(0,5))
        search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=search_var, width=30)
        search_entry.pack(side="left")
        
        # Create treeview with scrollbars
        tree_frame = tk.Frame(docs_frame)
        tree_frame.pack(fill="both", expand=True)
        
        # Create treeview
        columns = ("doc_name", "student_name", "student_id", "father_name", "last_name", 
                  "doc_type", "uploader", "upload_date")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")
        
        # Define column headings
        headings = {
            "doc_name": "Document Name",
            "student_name": "Student Name",
            "student_id": "Student ID",
            "father_name": "Father's Name",
            "last_name": "Last Name",
            "doc_type": "Document Type",
            "uploader": "Uploader",
            "upload_date": "Upload Date"
        }
        
        for col, heading in headings.items():
            tree.heading(col, text=heading)
            tree.column(col, width=150)  # Set column width
        
        # Add scrollbars
        y_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        x_scrollbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=y_scrollbar.set, xscrollcommand=x_scrollbar.set)
        
        # Pack scrollbars and tree
        y_scrollbar.pack(side="right", fill="y")
        x_scrollbar.pack(side="bottom", fill="x")
        tree.pack(fill="both", expand=True)
        
        def refresh_documents(search_term=""):
            # Clear existing items
            for item in tree.get_children():
                tree.delete(item)
            
            # Fetch documents from database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            if search_term:
                search_pattern = f"%{search_term}%"
                cursor.execute("""
                    SELECT id, document_name, student_name, student_id, father_name, last_name,
                           document_type, uploader, upload_date, file_path
                    FROM student_documents
                    WHERE document_name LIKE ? OR student_name LIKE ? OR student_id LIKE ?
                    ORDER BY upload_date DESC
                """, (search_pattern, search_pattern, search_pattern))
            else:
                cursor.execute("""
                    SELECT id, document_name, student_name, student_id, father_name, last_name,
                           document_type, uploader, upload_date, file_path
                    FROM student_documents
                    ORDER BY upload_date DESC
                """)
            
            # Store document data for editing and deleting
            self.document_data = {}
            
            for row in cursor.fetchall():
                # Insert into treeview (excluding id and file_path)
                item = tree.insert("", "end", values=row[1:-1])  # Exclude file_path from display
                # Store complete document data
                self.document_data[item] = {
                    'id': row[0],
                    'document_name': row[1],
                    'student_name': row[2],
                    'student_id': row[3],
                    'father_name': row[4],
                    'last_name': row[5],
                    'document_type': row[6],
                    'file_path': row[-1]
                }
            
            conn.close()
        
        def on_search(*args):
            refresh_documents(search_var.get())
        
        # Bind search entry to search function
        search_var.trace("w", on_search)
        
        def open_document(event):
            selected_item = tree.selection()
            if not selected_item:
                return
                
            file_path = self.document_data[selected_item[0]]['file_path']
            if not os.path.exists(file_path):
                messagebox.showerror("Error", "Document file not found")
                return
                
            try:
                os.startfile(file_path)
            except Exception as e:
                messagebox.showerror("Error", f"Could not open document: {str(e)}")
        
        def edit_document():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select a document to edit")
                return
            
            doc_data = self.document_data[selected_item[0]]
            
            # Create edit dialog
            edit_window = tk.Toplevel(self.root)
            edit_window.title("Edit Document")
            edit_window.geometry("500x600")
            edit_window.configure(bg="white")
            
            # Center the window
            edit_window.geometry(f"+{self.root.winfo_x() + 200}+{self.root.winfo_y() + 50}")
            
            # Make window modal
            edit_window.transient(self.root)
            edit_window.grab_set()
            
            # Create form
            form_frame = tk.Frame(edit_window, bg="white")
            form_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            tk.Label(form_frame, text="Edit Document", 
                    font=("Helvetica", 16, "bold"), bg="white").pack(pady=(0,20))
            
            # Document name
            tk.Label(form_frame, text="Document Name:", bg="white").pack(anchor="w")
            doc_name_entry = ttk.Entry(form_frame, width=40)
            doc_name_entry.insert(0, doc_data['document_name'])
            doc_name_entry.pack(fill="x", pady=(0,10))
            
            # Student name
            tk.Label(form_frame, text="Student Name:", bg="white").pack(anchor="w")
            student_name_entry = ttk.Entry(form_frame, width=40)
            student_name_entry.insert(0, doc_data['student_name'])
            student_name_entry.pack(fill="x", pady=(0,10))
            
            # Student ID
            tk.Label(form_frame, text="Student ID:", bg="white").pack(anchor="w")
            student_id_entry = ttk.Entry(form_frame, width=40)
            student_id_entry.insert(0, doc_data['student_id'])
            student_id_entry.pack(fill="x", pady=(0,10))
            
            # Father's name
            tk.Label(form_frame, text="Father's Name:", bg="white").pack(anchor="w")
            father_name_entry = ttk.Entry(form_frame, width=40)
            father_name_entry.insert(0, doc_data['father_name'])
            father_name_entry.pack(fill="x", pady=(0,10))
            
            # Last name
            tk.Label(form_frame, text="Last Name:", bg="white").pack(anchor="w")
            last_name_entry = ttk.Entry(form_frame, width=40)
            last_name_entry.insert(0, doc_data['last_name'])
            last_name_entry.pack(fill="x", pady=(0,10))
            
            # Document type dropdown
            tk.Label(form_frame, text="Document Type:", bg="white").pack(anchor="w")
            doc_types = [
                "National ID card",
                "School certificate",
                "Photo",
                "Transfer documents",
                "Deferment documents",
                "Diploma",
                "Transcript",
                "Passport",
                "CV",
                "Diploma and transcript application document",
                "Monograph Defense Paper"
            ]
            doc_type_var = tk.StringVar(value=doc_data['document_type'])
            doc_type_dropdown = ttk.Combobox(form_frame, textvariable=doc_type_var, 
                                           values=doc_types, width=37, state="readonly")
            doc_type_dropdown.pack(fill="x", pady=(0,10))
            
            def save_changes():
                # Validate inputs
                if not all([
                    doc_name_entry.get().strip(),
                    student_name_entry.get().strip(),
                    student_id_entry.get().strip(),
                    father_name_entry.get().strip(),
                    last_name_entry.get().strip(),
                    doc_type_var.get()
                ]):
                    messagebox.showerror("Error", "Please fill in all fields")
                    return
                
                # Update database
                conn = sqlite3.connect('document_management.db')
                cursor = conn.cursor()
                
                cursor.execute("""
                    UPDATE student_documents
                    SET document_name = ?, student_name = ?, student_id = ?,
                        father_name = ?, last_name = ?, document_type = ?
                    WHERE id = ?
                """, (
                    doc_name_entry.get().strip(),
                    student_name_entry.get().strip(),
                    student_id_entry.get().strip(),
                    father_name_entry.get().strip(),
                    last_name_entry.get().strip(),
                    doc_type_var.get(),
                    doc_data['id']
                ))
                
                conn.commit()
                conn.close()
                
                messagebox.showinfo("Success", "Document updated successfully!")
                edit_window.destroy()
                refresh_documents(search_var.get())  # Refresh the list
            
            # Save and Cancel buttons
            button_frame = tk.Frame(form_frame, bg="white")
            button_frame.pack(fill="x", pady=(20,0))
            
            ttk.Button(button_frame, text="Save Changes", command=save_changes).pack(side="left", padx=5)
            ttk.Button(button_frame, text="Cancel", command=edit_window.destroy).pack(side="left")
        
        def delete_document():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select a document to delete")
                return
            
            doc_data = self.document_data[selected_item[0]]
            
            # Confirm deletion
            if not messagebox.askyesno("Confirm Delete", 
                                     f"Are you sure you want to delete the document:\n{doc_data['document_name']}?"):
                return
            
            # Delete file
            try:
                if os.path.exists(doc_data['file_path']):
                    os.remove(doc_data['file_path'])
            except Exception as e:
                messagebox.showwarning("Warning", f"Could not delete file: {str(e)}")
            
            # Delete from database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            cursor.execute("DELETE FROM student_documents WHERE id = ?", (doc_data['id'],))
            
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Success", "Document deleted successfully!")
            refresh_documents(search_var.get())  # Refresh the list
        
        # Bind double-click to open document
        tree.bind("<Double-1>", open_document)
        
        # Create button frame
        button_frame = tk.Frame(docs_frame, bg="white")
        button_frame.pack(fill="x", pady=(10,0))
        
        # Add buttons
        ttk.Button(button_frame, text="View Selected", 
                  command=lambda: open_document(None)).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Delete", 
                  command=delete_document).pack(side="left", padx=5)
        
        # Initial load of documents
        refresh_documents()
        
        # Add help text
        tk.Label(docs_frame, text="Double-click on a document to open it • Select a document and use buttons to delete", 
                fg="gray", bg="white").pack(pady=(5,0))
    
    def view_messages(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
            
        # Create messages view
        messages_frame = tk.Frame(self.content_area, bg="white")
        messages_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title and message type selector
        header_frame = tk.Frame(messages_frame, bg="white")
        header_frame.pack(fill="x", pady=(0, 20))
        
        tk.Label(header_frame, text="Messages", font=("Helvetica", 18, "bold"), 
                bg="white").pack(side="left")
        
        message_type = tk.StringVar(value="private")
        ttk.Radiobutton(header_frame, text="Private Messages", variable=message_type, 
                       value="private", command=lambda: self.load_messages(message_type.get())).pack(side="right", padx=5)
        ttk.Radiobutton(header_frame, text="Public Messages", variable=message_type,
                       value="public", command=lambda: self.load_messages(message_type.get())).pack(side="right", padx=5)
        
        # Split frame for messages list and compose area
        split_frame = tk.Frame(messages_frame, bg="white")
        split_frame.pack(fill="both", expand=True)
        
        # Messages list (left side)
        messages_list_frame = tk.Frame(split_frame, bg="white", width=400)
        messages_list_frame.pack(side="left", fill="both", padx=(0, 10))
        
        # Message list canvas for scrolling
        canvas = tk.Canvas(messages_list_frame, bg="white")
        scrollbar = ttk.Scrollbar(messages_list_frame, orient="vertical", command=canvas.yview)
        self.messages_container = tk.Frame(canvas, bg="white")
        
        canvas.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        
        canvas.create_window((0, 0), window=self.messages_container, anchor="nw")
        self.messages_container.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        
        # Compose message area (right side)
        compose_frame = tk.LabelFrame(split_frame, text="Compose Message", bg="white", padx=10, pady=10)
        compose_frame.pack(side="right", fill="both", expand=True)
        
        # Receiver field (only for private messages)
        self.receiver_frame = tk.Frame(compose_frame, bg="white")
        self.receiver_frame.pack(fill="x", pady=(0, 10))
        tk.Label(self.receiver_frame, text="To:", bg="white").pack(side="left", padx=(0, 5))
        
        # Create combobox for user selection
        self.receiver_var = tk.StringVar()
        self.receiver_combobox = ttk.Combobox(self.receiver_frame, textvariable=self.receiver_var, state="readonly")
        self.receiver_combobox['values'] = self.get_all_users()
        self.receiver_combobox.pack(side="left", fill="x", expand=True)
        
        # Message text
        tk.Label(compose_frame, text="Message:", bg="white").pack(anchor="w")
        self.message_text = tk.Text(compose_frame, height=5)
        self.message_text.pack(fill="x", pady=(0, 10))
        
        # Attachment frame
        attachment_frame = tk.Frame(compose_frame, bg="white")
        attachment_frame.pack(fill="x", pady=(0, 10))
        
        self.attachment_label = tk.Label(attachment_frame, text="No file attached", bg="white")
        self.attachment_label.pack(side="left", padx=(0, 10))
        
        def browse_attachment():
            file_types = (
                ("All supported files", "*.pdf;*.png;*.jpeg;*.jpg;*.docx;*.doc;*.xls;*.xlsx"),
                ("PDF files", "*.pdf"),
                ("Image files", "*.png;*.jpeg;*.jpg"),
                ("Word documents", "*.docx;*.doc"),
                ("Excel files", "*.xls;*.xlsx")
            )
            file_path = filedialog.askopenfilename(filetypes=file_types)
            if file_path:
                self.current_attachment = file_path
                self.attachment_label.config(text=os.path.basename(file_path))
        
        ttk.Button(attachment_frame, text="Attach File", command=browse_attachment).pack(side="left")
        
        # Send button
        ttk.Button(compose_frame, text="Send Message", 
                  command=lambda: self.send_message(message_type.get())).pack(anchor="e")
        
        # Load initial messages
        self.load_messages(message_type.get())
        
        # Update UI based on message type
        def update_ui(*args):
            is_private = message_type.get() == "private"
            if is_private:
                self.receiver_frame.pack(fill="x", pady=(0, 10))
            else:
                self.receiver_frame.pack_forget()
        
        message_type.trace("w", update_ui)
        update_ui()

    def get_all_users(self):
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        cursor.execute("SELECT username FROM users WHERE username != ?", (self.current_user['username'],))
        users = [row[0] for row in cursor.fetchall()]
        conn.close()
        return users

    def load_messages(self, message_type):
        # Clear existing messages
        for widget in self.messages_container.winfo_children():
            widget.destroy()
        
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        
        if message_type == "private":
            # Load private messages (sent or received by current user)
            cursor.execute("""
                SELECT 
                    m.id,
                    m.sender,
                    m.receiver,
                    m.message_text,
                    m.is_public,
                    m.timestamp,
                    s.username as sender_name,
                    r.username as receiver_name
                FROM messages m
                JOIN users s ON m.sender = s.username
                LEFT JOIN users r ON m.receiver = r.username
                WHERE (m.sender = ? OR m.receiver = ?) 
                AND m.is_public = 0
                ORDER BY m.timestamp DESC
            """, (self.current_user['username'], self.current_user['username']))
        else:
            # Load public messages
            cursor.execute("""
                SELECT 
                    m.id,
                    m.sender,
                    m.receiver,
                    m.message_text,
                    m.is_public,
                    m.timestamp,
                    s.username as sender_name
                FROM messages m
                JOIN users s ON m.sender = s.username
                WHERE m.is_public = 1
                ORDER BY m.timestamp DESC
            """)
        
        messages = cursor.fetchall()
        
        for message in messages:
            message_frame = tk.Frame(self.messages_container, bg="white", relief="solid", borderwidth=1)
            message_frame.pack(fill="x", pady=5, padx=5)
            
            # Header (sender, receiver, timestamp)
            header_frame = tk.Frame(message_frame, bg="white")
            header_frame.pack(fill="x", padx=5, pady=5)
            
            if message_type == "private":
                if message[1] == self.current_user['username']:  # sender is current user
                    header_text = f"To: {message[7]}"  # receiver_name
                else:
                    header_text = f"From: {message[6]}"  # sender_name
            else:
                header_text = f"From: {message[6]}"  # sender_name
            
            tk.Label(header_frame, text=header_text, bg="white", font=("Helvetica", 10, "bold")).pack(side="left")
            
            # Format timestamp
            timestamp = datetime.datetime.strptime(message[5], '%Y-%m-%d %H:%M:%S')
            formatted_time = timestamp.strftime('%Y-%m-%d %I:%M %p')
            tk.Label(header_frame, text=formatted_time, bg="white", fg="gray").pack(side="right")
            
            # Message content
            tk.Label(message_frame, text=message[3], bg="white", wraplength=350, justify="left").pack(fill="x", padx=5, pady=5)
            
            # Check for attachments
            cursor.execute("SELECT * FROM message_attachments WHERE message_id = ?", (message[0],))
            attachments = cursor.fetchall()
            
            if attachments:
                attachment_frame = tk.Frame(message_frame, bg="white")
                attachment_frame.pack(fill="x", padx=5, pady=5)
                
                for attachment in attachments:
                    att_button = ttk.Button(attachment_frame, text=f" {attachment[2]}", 
                                          command=lambda fp=attachment[3]: os.startfile(fp))
                    att_button.pack(side="left", padx=2)
        
        conn.close()

    def send_message(self, message_type):
        message_text = self.message_text.get("1.0", "end-1c").strip()
        
        if not message_text:
            messagebox.showerror("Error", "Please enter a message")
            return
        
        is_public = message_type == "public"
        receiver = None if is_public else self.receiver_var.get()
        
        if not is_public and not receiver:
            messagebox.showerror("Error", "Please select a receiver")
            return
        
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        
        try:
            # Insert message
            cursor.execute("""
                INSERT INTO messages (sender, receiver, message_text, is_public)
                VALUES (?, ?, ?, ?)
            """, (self.current_user['username'], receiver if not is_public else "", message_text, is_public))
            
            message_id = cursor.lastrowid
            
            # Handle attachment if present
            if hasattr(self, 'current_attachment') and self.current_attachment:
                file_name = os.path.basename(self.current_attachment)
                file_type = os.path.splitext(file_name)[1].lower()
                
                # Create attachments directory if it doesn't exist
                attachments_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "message_attachments")
                os.makedirs(attachments_dir, exist_ok=True)
                
                # Copy file to attachments directory
                new_file_path = os.path.join(attachments_dir, f"{message_id}_{file_name}")
                shutil.copy2(self.current_attachment, new_file_path)
                
                # Save attachment info in database
                cursor.execute("""
                    INSERT INTO message_attachments (message_id, file_name, file_path, file_type)
                    VALUES (?, ?, ?, ?)
                """, (message_id, file_name, new_file_path, file_type))
            
            conn.commit()
            messagebox.showinfo("Success", "Message sent successfully!")
            
            # Clear form
            self.message_text.delete("1.0", "end")
            if hasattr(self, 'receiver_var'):
                self.receiver_var.set('')
            if hasattr(self, 'current_attachment'):
                delattr(self, 'current_attachment')
                self.attachment_label.config(text="No file attached")
            
            # Reload messages
            self.load_messages(message_type)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to send message: {str(e)}")
        finally:
            conn.close()
    
    def signup(self):
        username = self.new_username_entry.get()
        email = self.email_entry.get()
        password = self.new_password_entry.get()
        conf_password = self.conf_password_entry.get()
        
        if not username or not email or not password or not conf_password:
            messagebox.showerror("Error", "Please fill in all fields")
            return
        
        if not self.validate_email(email):
            messagebox.showerror("Error", "Please enter a valid email address")
            return
        
        if password != conf_password:
            messagebox.showerror("Error", "Passwords do not match")
            return
        
        if len(password) < 6:
            messagebox.showerror("Error", "Password must be at least 6 characters long")
            return
        
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        
        try:
            cursor.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                         (username, email, password))
            conn.commit()
            messagebox.showinfo("Success", "Account created successfully!")
            self.show_login()
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "Username or email already exists")
        finally:
            conn.close()

    def view_account_management(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        # Create account management view
        account_frame = tk.Frame(self.content_area, bg="white")
        account_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(account_frame, text="Account Management", 
                font=("Helvetica", 18, "bold"), bg="white").pack(pady=(0,20))
        
        # Create treeview with scrollbars
        tree_frame = tk.Frame(account_frame)
        tree_frame.pack(fill="both", expand=True)
        
        columns = ("username", "email", "is_admin")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")
        
        # Define column headings
        tree.heading("username", text="Username")
        tree.heading("email", text="Email")
        tree.heading("is_admin", text="Admin")
        
        # Add scrollbars
        y_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=y_scrollbar.set)
        
        # Pack scrollbars and tree
        y_scrollbar.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)
        
        def refresh_accounts():
            # Clear existing items
            for item in tree.get_children():
                tree.delete(item)
            
            # Fetch accounts from database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT username, email, is_admin
                FROM users
                WHERE email != ?
                ORDER BY username
            """, (self.current_user['email'],))
            
            for row in cursor.fetchall():
                tree.insert("", "end", values=(row[0], row[1], "Yes" if row[2] else "No"))
            
            conn.close()
        
        def edit_account():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select an account to edit")
                return
            
            # Get selected account data
            values = tree.item(selected_item[0])['values']
            username, email = values[0], values[1]
            
            # Create edit dialog
            edit_window = tk.Toplevel(self.root)
            edit_window.title("Edit Account")
            edit_window.geometry("400x300")
            edit_window.configure(bg="white")
            
            # Center the window
            edit_window.geometry(f"+{self.root.winfo_x() + 250}+{self.root.winfo_y() + 150}")
            
            # Make window modal
            edit_window.transient(self.root)
            edit_window.grab_set()
            
            # Create form
            form_frame = tk.Frame(edit_window, bg="white")
            form_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            tk.Label(form_frame, text="Edit Account", 
                    font=("Helvetica", 16, "bold"), bg="white").pack(pady=(0,20))
            
            # Username
            tk.Label(form_frame, text="Username:", bg="white").pack(anchor="w")
            username_entry = ttk.Entry(form_frame, width=40)
            username_entry.insert(0, username)
            username_entry.pack(fill="x", pady=(0,10))
            
            # Email
            tk.Label(form_frame, text="Email:", bg="white").pack(anchor="w")
            email_entry = ttk.Entry(form_frame, width=40)
            email_entry.insert(0, email)
            email_entry.pack(fill="x", pady=(0,10))
            
            # Reset Password
            tk.Label(form_frame, text="New Password (leave blank to keep unchanged):", 
                    bg="white").pack(anchor="w")
            password_entry = ttk.Entry(form_frame, width=40, show="●")
            password_entry.pack(fill="x", pady=(0,10))
            
            def save_changes():
                new_username = username_entry.get().strip()
                new_email = email_entry.get().strip()
                new_password = password_entry.get()
                
                if not new_username or not new_email:
                    messagebox.showerror("Error", "Username and email are required")
                    return
                
                if not self.validate_email(new_email):
                    messagebox.showerror("Error", "Please enter a valid email address")
                    return
                
                conn = sqlite3.connect('document_management.db')
                cursor = conn.cursor()
                
                try:
                    if new_password:
                        cursor.execute("""
                            UPDATE users 
                            SET username = ?, email = ?, password = ?
                            WHERE email = ?
                        """, (new_username, new_email, new_password, email))
                    else:
                        cursor.execute("""
                            UPDATE users 
                            SET username = ?, email = ?
                            WHERE email = ?
                        """, (new_username, new_email, email))
                    
                    conn.commit()
                    messagebox.showinfo("Success", "Account updated successfully!")
                    edit_window.destroy()
                    refresh_accounts()
                except sqlite3.IntegrityError:
                    messagebox.showerror("Error", "Username or email already exists")
                finally:
                    conn.close()
            
            # Save and Cancel buttons
            button_frame = tk.Frame(form_frame, bg="white")
            button_frame.pack(fill="x", pady=(20,0))
            
            ttk.Button(button_frame, text="Save Changes", command=save_changes).pack(side="left", padx=5)
            ttk.Button(button_frame, text="Cancel", command=edit_window.destroy).pack(side="left")
        
        def delete_account():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select an account to delete")
                return
            
            # Get selected account data
            values = tree.item(selected_item[0])['values']
            username, email = values[0], values[1]
            
            # Confirm deletion
            if not messagebox.askyesno("Confirm Delete", 
                                     f"Are you sure you want to delete the account:\n{username} ({email})?"):
                return
            
            # Delete from database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            try:
                cursor.execute("DELETE FROM users WHERE email = ?", (email,))
                conn.commit()
                messagebox.showinfo("Success", "Account deleted successfully!")
                refresh_accounts()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete account: {str(e)}")
            finally:
                conn.close()
        
        # Add action buttons
        ttk.Button(button_frame, text="Edit Account", command=edit_account).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Delete Account", command=delete_account).pack(side="left")
        
        # Load initial accounts
        refresh_accounts()

    def add_exam_result(self):
        # Create add exam result dialog
        add_window = tk.Toplevel(self.root)
        add_window.title("Add New Exam Result")
        add_window.geometry("500x800")  # Made taller to accommodate upload button
        add_window.configure(bg="white")
        
        # Center the window
        add_window.geometry(f"+{self.root.winfo_x() + 200}+{self.root.winfo_y() + 50}")
        
        # Make window modal
        add_window.transient(self.root)
        add_window.grab_set()
        
        # Create form
        form_frame = tk.Frame(add_window, bg="white")
        form_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(form_frame, text="Add New Exam Result", 
                font=("Helvetica", 16, "bold"), bg="white").pack(pady=(0,20))
        
        # Class Code
        tk.Label(form_frame, text="Class Code:", bg="white").pack(anchor="w")
        class_code_entry = ttk.Entry(form_frame, width=40)
        class_code_entry.pack(fill="x", pady=(0,10))
        
        # Department
        tk.Label(form_frame, text="Department:", bg="white").pack(anchor="w")
        department_entry = ttk.Entry(form_frame, width=40)
        department_entry.pack(fill="x", pady=(0,10))
        
        # Subject
        tk.Label(form_frame, text="Subject:", bg="white").pack(anchor="w")
        subject_entry = ttk.Entry(form_frame, width=40)
        subject_entry.pack(fill="x", pady=(0,10))
        
        # Teacher
        tk.Label(form_frame, text="Teacher:", bg="white").pack(anchor="w")
        teacher_entry = ttk.Entry(form_frame, width=40)
        teacher_entry.pack(fill="x", pady=(0,10))
        
        # Semester
        tk.Label(form_frame, text="Semester:", bg="white").pack(anchor="w")
        semester_var = tk.StringVar(value="1")
        semester_entry = ttk.Spinbox(form_frame, from_=1, to=8, textvariable=semester_var)
        semester_entry.pack(fill="x", pady=(0,10))
        
        # Semester Type
        tk.Label(form_frame, text="Semester Type:", bg="white").pack(anchor="w")
        semester_type_var = tk.StringVar(value="Fall")
        semester_type_combo = ttk.Combobox(form_frame, textvariable=semester_type_var, 
                                         values=["Fall", "Spring"], state="readonly")
        semester_type_combo.pack(fill="x", pady=(0,10))
        
        # Time Frame
        time_frame = tk.Frame(form_frame, bg="white")
        time_frame.pack(fill="x", pady=(0,10))
        
        # Start Time
        tk.Label(time_frame, text="Start Time:", bg="white").pack(side="left")
        start_hour_var = tk.StringVar(value="09")
        start_hour = ttk.Spinbox(time_frame, from_=0, to=23, width=3, textvariable=start_hour_var)
        start_hour.pack(side="left", padx=2)
        tk.Label(time_frame, text=":", bg="white").pack(side="left")
        start_minute_var = tk.StringVar(value="00")
        start_minute = ttk.Spinbox(time_frame, from_=0, to=59, width=3, textvariable=start_minute_var)
        start_minute.pack(side="left", padx=2)
        
        tk.Label(time_frame, text="  End Time:", bg="white").pack(side="left", padx=(10,0))
        end_hour_var = tk.StringVar(value="10")
        end_hour = ttk.Spinbox(time_frame, from_=0, to=23, width=3, textvariable=end_hour_var)
        end_hour.pack(side="left", padx=2)
        tk.Label(time_frame, text=":", bg="white").pack(side="left")
        end_minute_var = tk.StringVar(value="30")
        end_minute = ttk.Spinbox(time_frame, from_=0, to=59, width=3, textvariable=end_minute_var)
        end_minute.pack(side="left", padx=2)
        
        # Year
        tk.Label(form_frame, text="Year:", bg="white").pack(anchor="w")
        current_year = datetime.datetime.now().year
        year_var = tk.StringVar(value=str(current_year))
        year_entry = ttk.Spinbox(form_frame, from_=2000, to=2100, textvariable=year_var)
        year_entry.pack(fill="x", pady=(0,10))

        # Document Upload Section
        upload_frame = tk.Frame(form_frame, bg="white")
        upload_frame.pack(fill="x", pady=(10,20))
        
        tk.Label(upload_frame, text="Upload Document:", bg="white").pack(anchor="w")
        
        # Document info frame
        doc_info_frame = tk.Frame(upload_frame, bg="white")
        doc_info_frame.pack(fill="x", pady=(5,0))
        
        # Document path label
        doc_path_var = tk.StringVar(value="No document selected")
        doc_path_label = tk.Label(doc_info_frame, textvariable=doc_path_var, 
                                bg="white", fg="gray")
        doc_path_label.pack(side="left", fill="x", expand=True)
        
        def browse_document():
            filetypes = (
                ('PDF files', '*.pdf'),
                ('Word files', '*.doc;*.docx'),
                ('Excel files', '*.xls;*.xlsx'),
                ('Image files', '*.jpeg;*.jpg;*.png'),
            )
            filename = filedialog.askopenfilename(
                title='Select a document',
                filetypes=filetypes
            )
            if filename:
                # Store the full path but only display the filename
                doc_path_var.set(os.path.basename(filename))
                # Store the full path as an attribute
                upload_frame.document_path = filename
        
        # Browse button
        browse_button = ttk.Button(doc_info_frame, text="Browse", command=browse_document)
        browse_button.pack(side="right", padx=(5,0))
        
        def save_exam_result():
            # Validate inputs
            if not all([
                class_code_entry.get().strip(),
                department_entry.get().strip(),
                subject_entry.get().strip(),
                teacher_entry.get().strip(),
                semester_var.get(),
                semester_type_var.get(),
                start_hour_var.get(),
                start_minute_var.get(),
                end_hour_var.get(),
                end_minute_var.get(),
                year_var.get()
            ]):
                messagebox.showerror("Error", "Please fill in all fields")
                return
            
            # Format times
            try:
                start_time = f"{int(start_hour_var.get()):02d}:{int(start_minute_var.get()):02d}"
                end_time = f"{int(end_hour_var.get()):02d}:{int(end_minute_var.get()):02d}"
            except ValueError:
                messagebox.showerror("Error", "Invalid time format")
                return
            
            # Handle document
            document_path = None
            document_name = None
            document_type = None
            
            if hasattr(upload_frame, 'document_path'):
                source_path = upload_frame.document_path
                if os.path.exists(source_path):
                    # Create documents directory if it doesn't exist
                    doc_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'exam_documents')
                    os.makedirs(doc_dir, exist_ok=True)
                    
                    # Copy file to documents directory with unique name
                    new_filename = f"{int(time.time())}_{os.path.basename(source_path)}"
                    target_path = os.path.join(doc_dir, new_filename)
                    
                    # Copy file to documents directory
                    shutil.copy2(source_path, target_path)
                    
                    document_path = target_path
                    document_name = new_filename
                    document_type = os.path.splitext(new_filename)[1].lower()[1:]  # Remove the dot from extension
            
            # Save to database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            try:
                cursor.execute("""
                    INSERT INTO exam_results (
                        class_code, department, subject, teacher, semester,
                        semester_type, start_time, end_time, year, created_by,
                        document_path, document_name, document_type
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    class_code_entry.get().strip(),
                    department_entry.get().strip(),
                    subject_entry.get().strip(),
                    teacher_entry.get().strip(),
                    semester_var.get(),
                    semester_type_var.get(),
                    start_time,
                    end_time,
                    year_var.get(),
                    self.current_user['username'],
                    document_path,
                    document_name,
                    document_type
                ))
                
                conn.commit()
                messagebox.showinfo("Success", "Exam result added successfully!")
                add_window.destroy()
                self.refresh_exam_results()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add exam result: {str(e)}")
            finally:
                conn.close()
        
        # Save and Cancel buttons
        button_frame = tk.Frame(form_frame, bg="white")
        button_frame.pack(fill="x", pady=(20,0))
        
        ttk.Button(button_frame, text="Save", command=save_exam_result).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Cancel", command=add_window.destroy).pack(side="left")
    
    def view_exam_results(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        # Create exam results view
        exam_frame = tk.Frame(self.content_area, bg="white")
        exam_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title and add button frame
        header_frame = tk.Frame(exam_frame, bg="white")
        header_frame.pack(fill="x", pady=(0, 20))
        
        tk.Label(header_frame, text="Exam Results", 
                font=("Helvetica", 18, "bold"), bg="white").pack(side="left")
        
        # Add search box
        search_frame = tk.Frame(header_frame, bg="white")
        search_frame.pack(side="left", padx=20)
        
        tk.Label(search_frame, text="Search:", bg="white").pack(side="left", padx=(0, 5))
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *args: self.refresh_exam_results(self.search_var.get()))
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=30)
        search_entry.pack(side="left")
        
        # Create button frame
        button_frame = tk.Frame(header_frame, bg="white")
        button_frame.pack(side="right")

        ttk.Button(button_frame, text="Add New Exam Result", command=self.add_exam_result).pack(side="left", padx=5)

        if self.current_user['email'].lower().strip() == 'fiafghan@gmail.com':
            ttk.Button(button_frame, text="Delete Selected", command=self.delete_selected_results).pack(side="left", padx=5)

        # Create treeview with scrollbars
        tree_frame = tk.Frame(exam_frame)
        tree_frame.pack(fill="both", expand=True)
        
        columns = ("id", "class_code", "department", "subject", "teacher", "semester", 
                  "semester_type", "time", "year", "created_by", "document")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse")
        
        # Define column headings
        headings = {
            "id": "ID",
            "class_code": "Class Code",
            "department": "Department",
            "subject": "Subject",
            "teacher": "Teacher",
            "semester": "Semester",
            "semester_type": "Semester Type",
            "time": "Time",
            "year": "Year",
            "created_by": "Created By",
            "document": "Document"
        }
        
        for col, heading in headings.items():
            tree.heading(col, text=heading)
            tree.column(col, width=100)
        
        # Hide the ID column
        tree.column("id", width=0, stretch=False)
        
        # Add scrollbars
        y_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        x_scrollbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=y_scrollbar.set, xscrollcommand=x_scrollbar.set)
        
        # Pack scrollbars and tree
        y_scrollbar.pack(side="right", fill="y")
        x_scrollbar.pack(side="bottom", fill="x")
        tree.pack(fill="both", expand=True)
        
        def open_exam_document(event):
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select an exam result")
                return
            
            # Get the exam result ID
            exam_id = tree.item(selected_item[0])['values'][0]
            
            # Fetch document info
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT document_path, document_type
                FROM exam_results
                WHERE id = ?
            """, (exam_id,))
            
            result = cursor.fetchone()
            conn.close()
            
            if not result or not result[0]:
                messagebox.showinfo("Info", "No document attached to this exam result")
                return
            
            document_path, document_type = result
            
            if not os.path.exists(document_path):
                messagebox.showerror("Error", "Document file not found")
                return
            
            try:
                os.startfile(document_path)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open document: {str(e)}")
        
        tree.bind("<Double-1>", open_exam_document)
        
        def delete_selected():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select an exam result to delete")
                return
            
            # Get the exam result details
            values = tree.item(selected_item[0])['values']
            exam_id = values[0]
            class_code = values[1]
            subject = values[3]
            
            # Confirm deletion
            if not messagebox.askyesno("Confirm Delete", 
                                     f"Are you sure you want to delete the exam result for:\n{class_code} - {subject}?"):
                return
            
            # Delete from database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            try:
                cursor.execute("DELETE FROM exam_results WHERE id = ?", (exam_id,))
                conn.commit()
                messagebox.showinfo("Success", "Exam result deleted successfully!")
                self.refresh_exam_results()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete exam result: {str(e)}")
            finally:
                conn.close()
        
        # Add Delete button
        ttk.Button(button_frame, text="Delete Selected", 
                  command=delete_selected).pack(side="left", padx=5)
        
        # Initial refresh of exam results
        self.refresh_exam_results()
        
        # Add help text
        tk.Label(exam_frame, text="Double-click on an exam result to view • Select a result and use buttons to delete", 
                fg="gray", bg="white").pack(pady=(5,0))

    def refresh_exam_results(self, search_term=""):
        # Get the tree widget
        tree = None
        for widget in self.content_area.winfo_children():
            if isinstance(widget, tk.Frame):
                for child in widget.winfo_children():
                    if isinstance(child, tk.Frame):
                        for grandchild in child.winfo_children():
                            if isinstance(grandchild, ttk.Treeview):
                                tree = grandchild
                                break
        
        if not tree:
            return
            
        # Clear existing items
        for item in tree.get_children():
            tree.delete(item)
        
        # Fetch exam results from database
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        
        try:
            if search_term:
                search_pattern = f"%{search_term}%"
                cursor.execute("""
                    SELECT id, class_code, department, subject, teacher, semester, 
                           semester_type, start_time, end_time, year, created_by,
                           document_path, document_name
                    FROM exam_results
                    WHERE class_code LIKE ? OR department LIKE ? OR subject LIKE ? 
                          OR teacher LIKE ? OR semester_type LIKE ?
                    ORDER BY created_at DESC
                """, (search_pattern, search_pattern, search_pattern, search_pattern, search_pattern))
            else:
                cursor.execute("""
                    SELECT id, class_code, department, subject, teacher, semester, 
                           semester_type, start_time, end_time, year, created_by,
                           document_path, document_name
                    FROM exam_results
                    ORDER BY created_at DESC
                """)
            
            for row in cursor.fetchall():
                # Combine start_time and end_time for display
                time_str = f"{row[7]} - {row[8]}"
                
                # Get document info
                doc_info = "No document"
                if row[11]:  # document_path
                    doc_info = f"View {row[12]}"  # document_name
                
                # Create display tuple excluding individual time fields
                display_values = (row[0], row[1], row[2], row[3], row[4], row[5], 
                                row[6], time_str, row[9], row[10], doc_info)
                tree.insert("", "end", values=display_values)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to refresh exam results: {str(e)}")
        finally:
            conn.close()

    def show_results_page(self):
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        # Create frame for results page
        results_frame = tk.Frame(self.main_frame, bg="#f0f0f0")
        results_frame.pack(expand=True, fill="both", padx=20, pady=20)

        # Add title
        title_label = tk.Label(
            results_frame,
            text="Results Management",
            font=("Helvetica", 16, "bold"),
            bg="#f0f0f0"
        )
        title_label.pack(pady=10)

        # Create search frame
        search_frame = tk.Frame(results_frame, bg="#f0f0f0")
        search_frame.pack(fill="x", pady=5)

        # Add search entry
        tk.Label(search_frame, text="Search:", bg="#f0f0f0").pack(side="left", padx=5)
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self.search_results())
        search_entry = tk.Entry(search_frame, textvariable=self.search_var)
        search_entry.pack(side="left", fill="x", expand=True, padx=5)

        # Create form frame
        form_frame = tk.Frame(results_frame, bg="#f0f0f0")
        form_frame.pack(pady=10)

        # Add form fields
        labels = ['Class Code:', 'Faculty:', 'Department:', 'Year:', 'Semester:', 'Semester Type:']
        self.results_entries = {}

        for i, label in enumerate(labels):
            tk.Label(form_frame, text=label, bg="#f0f0f0").grid(row=i, column=0, padx=5, pady=5, sticky="e")
            
            if label == 'Semester Type:':
                semester_type = ttk.Combobox(form_frame, values=['fall', 'spring'], state='readonly')
                semester_type.grid(row=i, column=1, padx=5, pady=5, sticky="w")
                self.results_entries[label] = semester_type
            elif label == 'Semester:':
                semester = ttk.Spinbox(form_frame, from_=1, to=8, width=18)
                semester.grid(row=i, column=1, padx=5, pady=5, sticky="w")
                self.results_entries[label] = semester
            else:
                entry = tk.Entry(form_frame)
                entry.grid(row=i, column=1, padx=5, pady=5, sticky="w")
                self.results_entries[label] = entry

        # Create buttons frame
        buttons_frame = tk.Frame(form_frame, bg="#f0f0f0")
        buttons_frame.grid(row=len(labels), column=0, columnspan=2, pady=10)

        # Add buttons
        upload_btn = tk.Button(
            buttons_frame,
            text="Upload File",
            command=self.upload_result_file
        )
        upload_btn.pack(side="left", padx=5)

        edit_btn = tk.Button(
            buttons_frame,
            text="Edit Selected",
            command=self.edit_result,
            state="disabled"
        )
        edit_btn.pack(side="left", padx=5)
        self.edit_btn = edit_btn

        delete_btn = tk.Button(
            buttons_frame,
            text="Delete Selected",
            command=self.delete_result,
            state="disabled"
        )
        delete_btn.pack(side="left", padx=5)
        self.delete_btn = delete_btn

        clear_btn = tk.Button(
            buttons_frame,
            text="Clear Form",
            command=self.clear_form
        )
        clear_btn.pack(side="left", padx=5)

        # Add back button
        back_btn = tk.Button(
            results_frame,
            text="Back to Dashboard",
            command=self.show_dashboard
        )
        back_btn.pack(side="bottom", pady=10)

        # Add results table
        self.create_results_table(results_frame)
        
        # Variable to track if we're in edit mode
        self.editing_result_id = None

    def create_results_table(self, parent_frame):
        # Create table frame
        table_frame = tk.Frame(parent_frame, bg="#f0f0f0")
        table_frame.pack(expand=True, fill="both", pady=10)

        # Create treeview
        columns = ('ID', 'Class Code', 'Faculty', 'Department', 'Year', 'Semester', 'Semester Type', 'File Type', 'Upload Date')
        self.results_tree = ttk.Treeview(table_frame, columns=columns, show='headings')

        # Set column headings
        for col in columns:
            self.results_tree.heading(col, text=col)
            self.results_tree.column(col, width=100)

        # Hide ID column
        self.results_tree.column('ID', width=0, stretch=False)

        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.results_tree.yview)
        self.results_tree.configure(yscrollcommand=scrollbar.set)

        # Pack elements
        self.results_tree.pack(side="left", expand=True, fill="both")
        scrollbar.pack(side="right", fill="y")

        # Bind selection event
        self.results_tree.bind('<<TreeviewSelect>>', self.on_select)
        
        # Bind double-click event
        self.results_tree.bind('<Double-1>', self.open_result_file)

        # Load existing results
        self.load_results()

    def clear_form(self):
        for entry in self.results_entries.values():
            if isinstance(entry, ttk.Combobox):
                entry.set('')
            else:
                entry.delete(0, tk.END)
        self.delete_btn.config(state="disabled")
        self.edit_btn.config(state="disabled")
        self.results_tree.selection_remove(self.results_tree.selection())

    def on_select(self, event):
        selected_items = self.results_tree.selection()
        if selected_items:
            self.delete_btn.config(state="normal")
            self.edit_btn.config(state="normal")
        else:
            self.delete_btn.config(state="disabled")
            self.edit_btn.config(state="disabled")

    def delete_result(self):
        selected_items = self.results_tree.selection()
        if not selected_items:
            return

        if not messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this result?"):
            return

        try:
            # Get the ID of the selected item
            item = selected_items[0]
            result_id = self.results_tree.item(item)['values'][0]

            # Get file path before deleting from database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            cursor.execute('SELECT file_path FROM results WHERE id=?', (result_id,))
            file_path = cursor.fetchone()[0]

            # Delete from database
            cursor.execute('DELETE FROM results WHERE id=?', (result_id,))
            
            conn.commit()
            conn.close()

            # Delete file if it exists
            if os.path.exists(file_path):
                os.remove(file_path)

            messagebox.showinfo("Success", "Result deleted successfully!")
            self.clear_form()
            self.load_results()

        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete result: {str(e)}")

    def search_results(self):
        search_term = self.search_var.get().lower()
        
        # Clear existing items
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)

        # Get results from database
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, class_code, faculty, department, year, semester, semester_type, file_type, upload_date
            FROM results
            WHERE LOWER(class_code) LIKE ? OR 
                  LOWER(faculty) LIKE ? OR 
                  LOWER(department) LIKE ? OR 
                  LOWER(semester_type) LIKE ?
            ORDER BY upload_date DESC
        ''', (f'%{search_term}%', f'%{search_term}%', f'%{search_term}%', f'%{search_term}%'))
        
        # Insert results into treeview
        for row in cursor.fetchall():
            self.results_tree.insert('', 'end', values=row)
        
        conn.close()

    def load_results(self):
        # Clear existing items
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)

        # Get results from database
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, class_code, faculty, department, year, semester, semester_type, file_type, upload_date
            FROM results
            ORDER BY upload_date DESC
        ''')
        
        # Insert results into treeview
        for row in cursor.fetchall():
            self.results_tree.insert('', 'end', values=row)
        
        conn.close()

    def upload_result_file(self):
        # Get form values
        class_code = self.results_entries['Class Code:'].get()
        faculty = self.results_entries['Faculty:'].get()
        department = self.results_entries['Department:'].get()
        year = self.results_entries['Year:'].get()
        semester = self.results_entries['Semester:'].get()
        semester_type = self.results_entries['Semester Type:'].get()

        # Validate inputs
        if not all([class_code, faculty, department, year, semester, semester_type]):
            messagebox.showerror("Error", "All fields are required!")
            return
        
        try:
            year = int(year)
            semester = int(semester)
            if not (1 <= semester <= 8):
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Invalid year or semester value!")
            return

        # Check if a result for this class code and semester already exists
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT COUNT(*) FROM results 
            WHERE class_code = ? AND semester = ? AND year = ? AND semester_type = ?
        ''', (class_code, semester, year, semester_type))
        
        count = cursor.fetchone()[0]
        if count > 0:
            messagebox.showerror("Error", "A results table for this semester and this class code already exists!")
            conn.close()
            return

        # Open file dialog
        file_types = (
            ("All supported files", "*.pdf;*.xlsx;*.xls;*.doc;*.docx;*.jpeg;*.jpg;*.png"),
            ("PDF files", "*.pdf"),
            ("Excel files", "*.xlsx;*.xls"),
            ("Word files", "*.doc;*.docx"),
            ("Image files", "*.jpeg;*.jpg;*.png")
        )
        file_path = filedialog.askopenfilename(filetypes=file_types)
        
        if file_path:
            try:
                # Create results directory if it doesn't exist
                results_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')
                os.makedirs(results_dir, exist_ok=True)

                # Copy file to results directory
                file_name = os.path.basename(file_path)
                new_file_path = os.path.join(results_dir, file_name)
                shutil.copy2(file_path, new_file_path)

                # Save to database
                cursor.execute('''
                    INSERT INTO results (
                        class_code, faculty, department, year, semester, semester_type,
                        file_path, file_type, uploader
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    class_code, faculty, department, year, semester, semester_type,
                    new_file_path, os.path.splitext(file_name)[1], self.current_user['username']
                ))
                conn.commit()

                messagebox.showinfo("Success", "Result uploaded successfully!")
                
                # Clear form
                for entry in self.results_entries.values():
                    if isinstance(entry, ttk.Combobox):
                        entry.set('')
                    else:
                        entry.delete(0, tk.END)

                # Refresh results table
                self.load_results()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to upload result: {str(e)}")
            finally:
                conn.close()

    def edit_result(self):
        selected_items = self.results_tree.selection()
        if not selected_items:
            return

        # If we're already in edit mode
        if self.editing_result_id is not None:
            # Save the changes
            self.save_edited_result()
            return

        # Get the ID of the selected item
        item = selected_items[0]
        result_id = self.results_tree.item(item)['values'][0]

        # Fetch result data from database
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        cursor.execute('''
            SELECT class_code, faculty, department, year, semester, semester_type, file_path
            FROM results WHERE id=?
        ''', (result_id,))
        result_data = cursor.fetchone()
        conn.close()

        if not result_data:
            messagebox.showerror("Error", "Could not find the selected result.")
            return

        # Populate form fields with result data
        self.results_entries['Class Code:'].delete(0, tk.END)
        self.results_entries['Class Code:'].insert(0, result_data[0])
        
        self.results_entries['Faculty:'].delete(0, tk.END)
        self.results_entries['Faculty:'].insert(0, result_data[1])
        
        self.results_entries['Department:'].delete(0, tk.END)
        self.results_entries['Department:'].insert(0, result_data[2])
        
        self.results_entries['Year:'].delete(0, tk.END)
        self.results_entries['Year:'].insert(0, result_data[3])
        
        self.results_entries['Semester:'].delete(0, tk.END)
        self.results_entries['Semester:'].insert(0, result_data[4])
        
        self.results_entries['Semester Type:'].set(result_data[5])

        # Set editing_result_id to track that we're in edit mode
        self.editing_result_id = result_id

        # Change button text to "Save Changes"
        self.edit_btn.config(text="Save Changes")
        
        # Disable delete button during edit
        self.delete_btn.config(state="disabled")

    def save_edited_result(self):
        if self.editing_result_id is None:
            return

        # Get form values
        class_code = self.results_entries['Class Code:'].get()
        faculty = self.results_entries['Faculty:'].get()
        department = self.results_entries['Department:'].get()
        year = self.results_entries['Year:'].get()
        semester = self.results_entries['Semester:'].get()
        semester_type = self.results_entries['Semester Type:'].get()

        # Validate inputs
        if not all([class_code, faculty, department, year, semester, semester_type]):
            messagebox.showerror("Error", "All fields are required!")
            return
        
        try:
            year = int(year)
            semester = int(semester)
            if not (1 <= semester <= 8):
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Invalid year or semester value!")
            return
        
        try:
            # Connect to database
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()

            # Check if another result exists with the same class code and semester (excluding current record)
            cursor.execute('''
                SELECT COUNT(*) FROM results 
                WHERE class_code = ? AND semester = ? AND year = ? AND semester_type = ? AND id != ?
            ''', (class_code, semester, year, semester_type, self.editing_result_id))
            
            count = cursor.fetchone()[0]
            if count > 0:
                messagebox.showerror("Error", "A results table for this semester and this class code already exists!")
                conn.close()
                return

            # Update result in database
            cursor.execute('''
                UPDATE results
                SET class_code = ?, faculty = ?, department = ?, year = ?, semester = ?, semester_type = ?
                WHERE id = ?
            ''', (class_code, faculty, department, year, semester, semester_type, self.editing_result_id))
            
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Result updated successfully!")

            # Reset editing state
            self.editing_result_id = None
            self.edit_btn.config(text="Edit Selected")
            self.clear_form()
            
            # Refresh results table
            self.load_results()

        except Exception as e:
            messagebox.showerror("Error", f"Failed to update result: {str(e)}")

    def show_account_control(self):
        # Clear the root window
        for widget in self.root.winfo_children():
            widget.destroy()

        # Create new main frame
        self.main_frame = tk.Frame(self.root, bg="#f0f0f0")
        self.main_frame.pack(expand=True, fill="both", padx=20, pady=20)

        # Create main frame for account control
        main_frame = ttk.Frame(self.main_frame, padding="10")
        main_frame.pack(expand=True, fill="both")

        # Title
        title_label = ttk.Label(main_frame, text="Account Control Panel", font=('Helvetica', 16, 'bold'))
        title_label.pack(pady=10)

        # Create Treeview
        columns = ('ID', 'Username', 'Email')
        self.accounts_tree = ttk.Treeview(main_frame, columns=columns, show='headings')
        
        # Set column headings
        for col in columns:
            self.accounts_tree.heading(col, text=col)
            self.accounts_tree.column(col, width=150)

        self.accounts_tree.pack(pady=10, expand=True, fill="both")

        # Add scrollbar
        scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=self.accounts_tree.yview)
        self.accounts_tree.configure(yscrollcommand=scrollbar.set)

        # Pack elements
        scrollbar.pack(side="right", fill="y")
        self.accounts_tree.pack(side="left", expand=True, fill="both")

        # Buttons frame
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(pady=10)

        # Edit and Delete buttons
        edit_btn = ttk.Button(btn_frame, text="Edit Selected", command=self.edit_account_control)
        edit_btn.pack(side="left", padx=5)
        
        delete_btn = ttk.Button(btn_frame, text="Delete Selected", command=self.delete_account_control)
        delete_btn.pack(side="left", padx=5)

        # Back button
        back_btn = ttk.Button(btn_frame, text="Back to Dashboard", command=self.show_dashboard)
        back_btn.pack(side="left", padx=5)

        # Load accounts
        self.load_accounts_control()

    def load_accounts_control(self):
        # Clear existing items
        for item in self.accounts_tree.get_children():
            self.accounts_tree.delete(item)

        # Get all accounts except the current user
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        cursor.execute('SELECT id, username, email FROM users WHERE email != ?', (self.current_user['email'],))
        accounts = cursor.fetchall()
        conn.close()

        # Insert accounts into treeview
        for account in accounts:
            self.accounts_tree.insert('', tk.END, values=account)

    def edit_account_control(self):
        selected_item = self.accounts_tree.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "Please select an account to edit")
            return

        # Get selected account details
        account_id = self.accounts_tree.item(selected_item)['values'][0]
        
        # Create edit window
        edit_window = tk.Toplevel(self.root)
        edit_window.title("Edit Account")
        edit_window.geometry("300x400")  # Increased height for password fields

        # Get current values
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        cursor.execute('SELECT username, email FROM users WHERE id = ?', (account_id,))
        current_values = cursor.fetchone()
        conn.close()

        # Create and pack widgets
        ttk.Label(edit_window, text="Username:").pack(pady=5)
        username_var = tk.StringVar(value=current_values[0])
        username_entry = ttk.Entry(edit_window, textvariable=username_var)
        username_entry.pack(pady=5)

        ttk.Label(edit_window, text="Email:").pack(pady=5)
        email_var = tk.StringVar(value=current_values[1])
        email_entry = ttk.Entry(edit_window, textvariable=email_var)
        email_entry.pack(pady=5)

        # Add password fields
        ttk.Label(edit_window, text="New Password (leave blank to keep current):").pack(pady=5)
        password_var = tk.StringVar()
        password_entry = ttk.Entry(edit_window, textvariable=password_var, show="●")
        password_entry.pack(pady=5)

        ttk.Label(edit_window, text="Confirm New Password:").pack(pady=5)
        confirm_password_var = tk.StringVar()
        confirm_password_entry = ttk.Entry(edit_window, textvariable=confirm_password_var, show="●")
        confirm_password_entry.pack(pady=5)

        def save_changes():
            new_username = username_var.get().strip()
            new_email = email_var.get().strip()
            new_password = password_var.get()
            confirm_password = confirm_password_var.get()
            
            # Validate inputs
            if not new_username or not new_email:
                messagebox.showerror("Error", "Username and email are required!")
                return

            # Validate passwords if provided
            if new_password or confirm_password:
                if new_password != confirm_password:
                    messagebox.showerror("Error", "Passwords do not match!")
                    return
                if len(new_password) < 6:
                    messagebox.showerror("Error", "Password must be at least 6 characters long!")
                    return

            try:
                # Check if username or email exists for other users
                conn = sqlite3.connect('document_management.db')
                cursor = conn.cursor()
                
                # Only check for duplicates if the values have changed
                if new_username != current_values[0]:
                    cursor.execute('SELECT id FROM users WHERE username = ? AND id != ?', (new_username, account_id))
                    if cursor.fetchone():
                        messagebox.showerror("Error", "This username is already taken!")
                        conn.close()
                        return

                if new_email != current_values[1]:
                    cursor.execute('SELECT id FROM users WHERE email = ? AND id != ?', (new_email, account_id))
                    if cursor.fetchone():
                        messagebox.showerror("Error", "This email is already taken!")
                        conn.close()
                        return

                # If all checks pass, update the user
                if new_password:
                    cursor.execute("""
                        UPDATE users 
                        SET username = ?, email = ?, password = ?
                        WHERE id = ?
                    """, (new_username, new_email, new_password, account_id))
                else:
                    cursor.execute("""
                        UPDATE users 
                        SET username = ?, email = ?
                        WHERE id = ?
                    """, (new_username, new_email, account_id))
                
                conn.commit()
                conn.close()
                
                # Refresh treeview
                self.load_accounts_control()
                edit_window.destroy()
                messagebox.showinfo("Success", "Account updated successfully!")
                
            except sqlite3.Error as e:
                messagebox.showerror("Database Error", f"Failed to update account: {str(e)}")
                if 'conn' in locals():
                    conn.close()
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
                if 'conn' in locals():
                    conn.close()

        ttk.Button(edit_window, text="Save Changes", command=save_changes).pack(pady=10)

    def delete_account_control(self):
        selected_item = self.accounts_tree.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "Please select an account to delete")
            return

        # Get selected account details
        account_id = self.accounts_tree.item(selected_item)['values'][0]
        account_email = self.accounts_tree.item(selected_item)['values'][2]

        # Confirm deletion
        if messagebox.askyesno("Confirm Delete", 
                             f"Are you sure you want to delete the account:\n{account_email}?"):
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            cursor.execute('DELETE FROM users WHERE id = ?', (account_id,))
            conn.commit()
            conn.close()

            # Refresh treeview
            self.load_accounts_control()
            messagebox.showinfo("Success", "Account deleted successfully!")

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def view_statistics(self):
        # Clear content area
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        # Create statistics view
        stats_frame = tk.Frame(self.content_area, bg="white")
        stats_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(stats_frame, text="System Statistics", 
                font=("Helvetica", 18, "bold"), bg="white").pack(pady=(0,20))
        
        # Create scrollable frame for statistics
        canvas = tk.Canvas(stats_frame, bg="white")
        scrollbar = ttk.Scrollbar(stats_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack the canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True, padx=(0, 5))
        scrollbar.pack(side="right", fill="y")
        
        # Fetch statistics from database
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        
        # Get current month and year
        current_date = datetime.datetime.now()
        current_month = current_date.strftime('%Y-%m')
        current_year = current_date.strftime('%Y')
        
        # 1. Document Statistics
        tk.Label(scrollable_frame, text="Document Statistics", 
                font=("Helvetica", 14, "bold"), bg="white").pack(pady=(10, 5))
        
        # Documents this month
        cursor.execute("""
            SELECT COUNT(*) FROM student_documents 
            WHERE strftime('%Y-%m', upload_date) = ?
        """, (current_month,))
        docs_this_month = cursor.fetchone()[0]
        
        # Documents this year
        cursor.execute("""
            SELECT COUNT(*) FROM student_documents 
            WHERE strftime('%Y', upload_date) = ?
        """, (current_year,))
        docs_this_year = cursor.fetchone()[0]
        
        # Documents by category this month
        cursor.execute("""
            SELECT document_type, COUNT(*) 
            FROM student_documents 
            WHERE strftime('%Y-%m', upload_date) = ?
            GROUP BY document_type
            ORDER BY COUNT(*) DESC
        """, (current_month,))
        docs_by_category_month = cursor.fetchall()
        
        # Documents by category this year
        cursor.execute("""
            SELECT document_type, COUNT(*) 
            FROM student_documents 
            WHERE strftime('%Y', upload_date) = ?
            GROUP BY document_type
            ORDER BY COUNT(*) DESC
        """, (current_year,))
        docs_by_category_year = cursor.fetchall()
        
        # Documents by user this month
        cursor.execute("""
            SELECT uploader, COUNT(*) 
            FROM student_documents 
            WHERE strftime('%Y-%m', upload_date) = ?
            GROUP BY uploader
            ORDER BY COUNT(*) DESC
        """, (current_month,))
        docs_by_user_month = cursor.fetchall()
        
        # Documents by user this year
        cursor.execute("""
            SELECT uploader, COUNT(*) 
            FROM student_documents 
            WHERE strftime('%Y', upload_date) = ?
            GROUP BY uploader
            ORDER BY COUNT(*) DESC
        """, (current_year,))
        docs_by_user_year = cursor.fetchall()
        
        # Display document statistics
        tk.Label(scrollable_frame, text=f"Monthly Overview ({current_date.strftime('%B %Y')})", 
                font=("Helvetica", 12, "bold"), bg="white").pack(pady=(5, 5))
        tk.Label(scrollable_frame, text=f"Total Documents Uploaded: {docs_this_month}", 
                font=("Helvetica", 12), bg="white").pack(pady=(0, 5))
        
        if docs_by_category_month:
            tk.Label(scrollable_frame, text="Documents by Category (This Month):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(5, 2))
            for category, count in docs_by_category_month:
                tk.Label(scrollable_frame, text=f"{category}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        if docs_by_user_month:
            tk.Label(scrollable_frame, text="Documents by User (This Month):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(10, 2))
            for user, count in docs_by_user_month:
                tk.Label(scrollable_frame, text=f"{user}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        tk.Label(scrollable_frame, text=f"\nYearly Overview ({current_year})", 
                font=("Helvetica", 12, "bold"), bg="white").pack(pady=(15, 5))
        tk.Label(scrollable_frame, text=f"Total Documents Uploaded: {docs_this_year}", 
                font=("Helvetica", 12), bg="white").pack(pady=(0, 5))
        
        if docs_by_category_year:
            tk.Label(scrollable_frame, text="Documents by Category (This Year):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(5, 2))
            for category, count in docs_by_category_year:
                tk.Label(scrollable_frame, text=f"{category}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        if docs_by_user_year:
            tk.Label(scrollable_frame, text="Documents by User (This Year):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(10, 2))
            for user, count in docs_by_user_year:
                tk.Label(scrollable_frame, text=f"{user}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        # 2. Exam Results Statistics
        tk.Label(scrollable_frame, text="\nExam Results Statistics", 
                font=("Helvetica", 14, "bold"), bg="white").pack(pady=(20, 5))
        
        # Total exam results this month
        cursor.execute("""
            SELECT COUNT(*) FROM exam_results 
            WHERE strftime('%Y-%m', created_at) = ?
        """, (current_month,))
        exams_this_month = cursor.fetchone()[0]
        
        # Total exam results this year
        cursor.execute("""
            SELECT COUNT(*) FROM exam_results 
            WHERE strftime('%Y', created_at) = ?
        """, (current_year,))
        exams_this_year = cursor.fetchone()[0]
        
        # Exam results by department this month
        cursor.execute("""
            SELECT department, COUNT(*) 
            FROM exam_results 
            WHERE strftime('%Y-%m', created_at) = ?
            GROUP BY department
            ORDER BY COUNT(*) DESC
        """, (current_month,))
        exams_by_dept_month = cursor.fetchall()
        
        # Exam results by department this year
        cursor.execute("""
            SELECT department, COUNT(*) 
            FROM exam_results 
            WHERE strftime('%Y', created_at) = ?
            GROUP BY department
            ORDER BY COUNT(*) DESC
        """, (current_year,))
        exams_by_dept_year = cursor.fetchall()
        
        # Display exam statistics
        tk.Label(scrollable_frame, text=f"Monthly Overview ({current_date.strftime('%B %Y')})", 
                font=("Helvetica", 12, "bold"), bg="white").pack(pady=(5, 5))
        tk.Label(scrollable_frame, text=f"Total Exam Results: {exams_this_month}", 
                font=("Helvetica", 12), bg="white").pack(pady=(0, 5))
        
        if exams_by_dept_month:
            tk.Label(scrollable_frame, text="Results by Department (This Month):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(5, 2))
            for dept, count in exams_by_dept_month:
                tk.Label(scrollable_frame, text=f"{dept}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        tk.Label(scrollable_frame, text=f"\nYearly Overview ({current_year})", 
                font=("Helvetica", 12, "bold"), bg="white").pack(pady=(15, 5))
        tk.Label(scrollable_frame, text=f"Total Exam Results: {exams_this_year}", 
                font=("Helvetica", 12), bg="white").pack(pady=(0, 5))
        
        if exams_by_dept_year:
            tk.Label(scrollable_frame, text="Results by Department (This Year):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(5, 2))
            for dept, count in exams_by_dept_year:
                tk.Label(scrollable_frame, text=f"{dept}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        # 3. Results Table Statistics
        tk.Label(scrollable_frame, text="\nResults Table Statistics", 
                font=("Helvetica", 14, "bold"), bg="white").pack(pady=(20, 5))
        
        # Total results this month
        cursor.execute("""
            SELECT COUNT(*) FROM results 
            WHERE strftime('%Y-%m', upload_date) = ?
        """, (current_month,))
        results_this_month = cursor.fetchone()[0]
        
        # Total results this year
        cursor.execute("""
            SELECT COUNT(*) FROM results 
            WHERE strftime('%Y', upload_date) = ?
        """, (current_year,))
        results_this_year = cursor.fetchone()[0]
        
        # Results by department this month
        cursor.execute("""
            SELECT department, COUNT(*) 
            FROM results 
            WHERE strftime('%Y-%m', upload_date) = ?
            GROUP BY department
            ORDER BY COUNT(*) DESC
        """, (current_month,))
        results_by_dept_month = cursor.fetchall()
        
        # Results by department this year
        cursor.execute("""
            SELECT department, COUNT(*) 
            FROM results 
            WHERE strftime('%Y', upload_date) = ?
            GROUP BY department
            ORDER BY COUNT(*) DESC
        """, (current_year,))
        results_by_dept_year = cursor.fetchall()
        
        # Display results table statistics
        tk.Label(scrollable_frame, text=f"Monthly Overview ({current_date.strftime('%B %Y')})", 
                font=("Helvetica", 12, "bold"), bg="white").pack(pady=(5, 5))
        tk.Label(scrollable_frame, text=f"Total Results Tables: {results_this_month}", 
                font=("Helvetica", 12), bg="white").pack(pady=(0, 5))
        
        if results_by_dept_month:
            tk.Label(scrollable_frame, text="Results by Department (This Month):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(5, 2))
            for dept, count in results_by_dept_month:
                tk.Label(scrollable_frame, text=f"{dept}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        tk.Label(scrollable_frame, text=f"\nYearly Overview ({current_year})", 
                font=("Helvetica", 12, "bold"), bg="white").pack(pady=(15, 5))
        tk.Label(scrollable_frame, text=f"Total Results Tables: {results_this_year}", 
                font=("Helvetica", 12), bg="white").pack(pady=(0, 5))
        
        if results_by_dept_year:
            tk.Label(scrollable_frame, text="Results by Department (This Year):", 
                    font=("Helvetica", 12), bg="white").pack(pady=(5, 2))
            for dept, count in results_by_dept_year:
                tk.Label(scrollable_frame, text=f"{dept}: {count}", 
                        font=("Helvetica", 12), bg="white").pack(pady=1)
        
        conn.close()
    
    def open_result_file(self, event):
        selected_items = self.results_tree.selection()
        if not selected_items:
            return

        # Get the ID of the selected item
        item = selected_items[0]
        result_id = self.results_tree.item(item)['values'][0]

        # Fetch file path from database
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        cursor.execute('SELECT file_path FROM results WHERE id=?', (result_id,))
        result = cursor.fetchone()
        conn.close()

        if not result or not result[0]:
            messagebox.showinfo("Info", "No file attached to this result")
            return

        file_path = result[0]
        if not os.path.exists(file_path):
            messagebox.showerror("Error", "File not found")
            return

        try:
            if hasattr(sys, '_MEIPASS'):
                # If running as exe, use absolute path
                abs_path = os.path.abspath(file_path)
            else:
                abs_path = file_path
            os.startfile(abs_path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open file: {str(e)}")

    def view_attendance_upload(self):
        for widget in self.content_area.winfo_children():
            widget.destroy()
        
        attendance_frame = tk.Frame(self.content_area, bg="white")
        attendance_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(attendance_frame, text="Upload Attendance", 
                font=("Helvetica", 18, "bold"), bg="white").pack(pady=(0,20))
        
        form_frame = tk.Frame(attendance_frame, bg="white")
        form_frame.pack(fill="x", padx=20)
        
        fields = [
            ("Class Code:", "class_code"),
            ("Faculty:", "faculty"),
            ("Department:", "department"),
            ("Subject:", "subject"),
            ("Teacher:", "teacher"),
            ("Year:", "year")
        ]
        
        entries = {}
        for i, (label_text, field_name) in enumerate(fields):
            tk.Label(form_frame, text=label_text, bg="white").grid(row=i, column=0, sticky="e", padx=10, pady=5)
            entry = ttk.Entry(form_frame)
            entry.grid(row=i, column=1, sticky="w", pady=5)
            entries[field_name] = entry
        
        tk.Label(form_frame, text="Semester:", bg="white").grid(row=len(fields), column=0, sticky="e", padx=10, pady=5)
        semester_spinbox = ttk.Spinbox(form_frame, from_=1, to=8, width=18)
        semester_spinbox.grid(row=len(fields), column=1, sticky="w", pady=5)
        
        tk.Label(form_frame, text="Semester Type:", bg="white").grid(row=len(fields)+1, column=0, sticky="e", padx=10, pady=5)
        semester_type = ttk.Combobox(form_frame, values=['fall', 'spring'], state='readonly')
        semester_type.grid(row=len(fields)+1, column=1, sticky="w", pady=5)
        
        file_frame = tk.Frame(attendance_frame, bg="white")
        file_frame.pack(fill="x", padx=20, pady=20)
        
        self.attendance_file_path = None
        self.attendance_file_label = tk.Label(file_frame, text="No file selected", bg="white")
        self.attendance_file_label.pack(side="left", padx=(0, 10))
        
        def browse_file():
            file_types = (
                ("All supported files", "*.pdf;*.docx;*.doc;*.xls;*.xlsx;*.png;*.jpg;*.jpeg"),
                ("PDF files", "*.pdf"),
                ("Word documents", "*.docx;*.doc"),
                ("Excel files", "*.xls;*.xlsx"),
                ("Image files", "*.png;*.jpg;*.jpeg")
            )
            file_path = filedialog.askopenfilename(filetypes=file_types)
            if file_path:
                self.attendance_file_path = file_path
                self.attendance_file_label.config(text=os.path.basename(file_path))
        
        ttk.Button(file_frame, text="Browse File", command=browse_file).pack(side="left")
        
        def save_attendance():
            if not all([entries[field].get().strip() for field in entries] + 
                      [semester_spinbox.get().strip(), semester_type.get(), self.attendance_file_path]):
                messagebox.showerror("Error", "All fields are required")
                return
            
            try:
                year = int(entries['year'].get().strip())
                semester = int(semester_spinbox.get().strip())
            except ValueError:
                messagebox.showerror("Error", "Year and semester must be valid numbers")
                return
            
            if semester < 1 or semester > 8:
                messagebox.showerror("Error", "Semester must be between 1 and 8")
                return
            
            dest_dir = os.path.join("uploads", "attendance")
            os.makedirs(dest_dir, exist_ok=True)
            
            file_name = os.path.basename(self.attendance_file_path)
            file_ext = os.path.splitext(file_name)[1]
            new_file_name = f"{entries['class_code'].get().strip()}_{entries['subject'].get().strip()}_{int(time.time())}{file_ext}"
            dest_path = os.path.join(dest_dir, new_file_name)
            
            try:
                shutil.copy2(self.attendance_file_path, dest_path)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save file: {str(e)}")
                return
            
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            
            try:
                cursor.execute("""
                    INSERT INTO attendance (
                        class_code, faculty, department, subject, teacher,
                        year, semester, semester_type, file_path, file_type,
                        uploader
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entries['class_code'].get().strip(),
                    entries['faculty'].get().strip(),
                    entries['department'].get().strip(),
                    entries['subject'].get().strip(),
                    entries['teacher'].get().strip(),
                    year,
                    semester,
                    semester_type.get(),
                    dest_path,
                    file_ext[1:],
                    self.current_user['username']
                ))
                
                conn.commit()
                messagebox.showinfo("Success", "Attendance record saved successfully!")
                
                for entry in entries.values():
                    entry.delete(0, tk.END)
                semester_spinbox.delete(0, tk.END)
                semester_spinbox.insert(0, "1")
                semester_type.set('')
                self.attendance_file_path = None
                self.attendance_file_label.config(text="No file selected")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save attendance record: {str(e)}")
                conn.rollback()
            finally:
                conn.close()
        
        ttk.Button(attendance_frame, text="Save Attendance", 
                  command=save_attendance).pack(pady=20)

    def view_attendance(self):
        for widget in self.content_area.winfo_children():
            widget.destroy()

        main_frame = tk.Frame(self.content_area, bg="white")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Attendance Records", font=("Helvetica", 18, "bold"), bg="white").pack(pady=(0, 20))

        # Tree frame
        tree_frame = ttk.Frame(main_frame)
        tree_frame.pack(fill="both", expand=True)

        # Treeview
        columns = ("ID", "Class Code", "Subject", "Faculty", "Department", "Teacher", "Year", "Semester", "Semester Type", "Upload Date", "Uploader")
        self.attendance_tree = ttk.Treeview(tree_frame, columns=columns, show="headings")
        for col in columns:
            self.attendance_tree.heading(col, text=col)
            self.attendance_tree.column(col, width=100)

        # Scrollbars
        y_scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.attendance_tree.yview)
        x_scrollbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.attendance_tree.xview)
        self.attendance_tree.configure(yscrollcommand=y_scrollbar.set, xscrollcommand=x_scrollbar.set)
        y_scrollbar.pack(side="right", fill="y")
        x_scrollbar.pack(side="bottom", fill="x")
        self.attendance_tree.pack(fill="both", expand=True)

        # Load data
        conn = sqlite3.connect('document_management.db')
        cursor = conn.cursor()
        try:
            cursor.execute('''
                SELECT id, class_code, subject, faculty, department, teacher,
                       year, semester, semester_type, upload_date, uploader
                FROM attendance
                ORDER BY upload_date DESC
            ''')
            for row in cursor.fetchall():
                self.attendance_tree.insert('', tk.END, values=row)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load records: {str(e)}")
        finally:
            conn.close()

        # Button frame
        button_frame = tk.Frame(main_frame, bg="white")
        button_frame.pack(fill="x", pady=10)

        def open_file():
            selected = self.attendance_tree.selection()
            if not selected:
                messagebox.showwarning("Warning", "Please select a record to open")
                return
            
            item = selected[0]
            attendance_id = self.attendance_tree.item(item)['values'][0]
            
            conn = sqlite3.connect('document_management.db')
            cursor = conn.cursor()
            try:
                cursor.execute('SELECT file_path FROM attendance WHERE id=?', (attendance_id,))
                file_path = cursor.fetchone()[0]
                if os.path.exists(file_path):
                    os.startfile(file_path)
                else:
                    messagebox.showerror("Error", "File not found")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open file: {str(e)}")
            finally:
                conn.close()

        ttk.Button(button_frame, text="Open File", command=open_file).pack(side="left", padx=5)

if __name__ == "__main__":
    root = tk.Tk()
    app = DocumentManagementSystem(root)
    root.mainloop()
